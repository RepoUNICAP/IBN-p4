/* -*- P4_16 -*- */
/* ibn_simple.p4 = o basic.p4 do tutorial + 3 coisas:
 *   1. header TCP (para ver a flag SYN)
 *   2. tabela  acl        -> intencao "bloquear host X"
 *   3. registradores      -> intencao "bloquear varreduras"
 *        limite[1]        : quantos SYNs um host pode mandar (0 = desligado)
 *        syn_count[1024]  : quantos SYNs cada host ja mandou
 * O programa nao muda com a intencao: o controlador so escreve nesses lugares. */
#include <core.p4>
#include <v1model.p4>

const bit<16> TYPE_IPV4 = 0x800;
const bit<8>  PROTO_TCP = 6;

typedef bit<9>  egressSpec_t;
typedef bit<48> macAddr_t;
typedef bit<32> ip4Addr_t;

header ethernet_t {
    macAddr_t dstAddr;
    macAddr_t srcAddr;
    bit<16>   etherType;
}

header ipv4_t {
    bit<4>    version;
    bit<4>    ihl;
    bit<8>    diffserv;
    bit<16>   totalLen;
    bit<16>   identification;
    bit<3>    flags;
    bit<13>   fragOffset;
    bit<8>    ttl;
    bit<8>    protocol;
    bit<16>   hdrChecksum;
    ip4Addr_t srcAddr;
    ip4Addr_t dstAddr;
}

header tcp_t {
    bit<16> srcPort;
    bit<16> dstPort;
    bit<32> seqNo;
    bit<32> ackNo;
    bit<4>  dataOffset;
    bit<3>  res;
    bit<1>  ns;
    bit<1>  cwr;
    bit<1>  ece;
    bit<1>  urg;
    bit<1>  ack;
    bit<1>  psh;
    bit<1>  rst;
    bit<1>  syn;
    bit<1>  fin;
    bit<16> window;
    bit<16> checksum;
    bit<16> urgentPtr;
}

struct metadata {
    /* empty */
}

struct headers {
    ethernet_t ethernet;
    ipv4_t     ipv4;
    tcp_t      tcp;
}

/*************************  P A R S E R  *********************************/
parser MyParser(packet_in packet,
                out headers hdr,
                inout metadata meta,
                inout standard_metadata_t standard_metadata) {

    state start {
        transition parse_ethernet;
    }

    state parse_ethernet {
        packet.extract(hdr.ethernet);
        transition select(hdr.ethernet.etherType) {
            TYPE_IPV4: parse_ipv4;
            default: accept;
        }
    }

    state parse_ipv4 {
        packet.extract(hdr.ipv4);
        transition select(hdr.ipv4.protocol) {
            PROTO_TCP: parse_tcp;   /* novo: se for TCP, pega o header TCP */
            default: accept;
        }
    }

    state parse_tcp {
        packet.extract(hdr.tcp);
        transition accept;
    }
}

control MyVerifyChecksum(inout headers hdr, inout metadata meta) {
    apply { }
}

/*************************  I N G R E S S  *******************************/
control MyIngress(inout headers hdr,
                  inout metadata meta,
                  inout standard_metadata_t standard_metadata) {

    register<bit<32>>(1)    limite;      /* escrito pela intencao "bloquear varreduras" */
    register<bit<32>>(1024) syn_count;   /* SYNs por host (indice = hash do IP origem)  */
    register<bit<48>>(1024) inicio;      /* quando a janela de 10 s de cada host comecou */
    const bit<48> JANELA = 10000000;     /* 10 s, em microssegundos                      */

    action drop() {
        mark_to_drop(standard_metadata);
    }

    action ipv4_forward(macAddr_t dstAddr, egressSpec_t port) {
        standard_metadata.egress_spec = port;
        hdr.ethernet.srcAddr = hdr.ethernet.dstAddr;
        hdr.ethernet.dstAddr = dstAddr;
        hdr.ipv4.ttl = hdr.ipv4.ttl - 1;
    }

    /* intencao "bloquear host X": o controlador faz table_add acl drop X */
    table acl {
        key = {
            hdr.ipv4.srcAddr: exact;
        }
        actions = {
            drop;
            NoAction;
        }
        size = 256;
        default_action = NoAction();
    }

    table ipv4_lpm {
        key = {
            hdr.ipv4.dstAddr: lpm;
        }
        actions = {
            ipv4_forward;
            drop;
            NoAction;
        }
        size = 1024;
        default_action = drop();
    }

    apply {
        if (hdr.ipv4.isValid()) {
            /* 1) host bloqueado por intencao? (hit = casou na acl = ja foi p/ drop) */
            if (!acl.apply().hit) {

                bit<1> scanner = 0;

                /* 2) detector: conta SYN "puro" (abertura de conexao) por host */
                if (hdr.tcp.isValid() && hdr.tcp.syn == 1 && hdr.tcp.ack == 0) {
                    bit<32> idx;
                    bit<32> n;
                    bit<32> lim;
                    hash(idx, HashAlgorithm.crc32, 32w0, { hdr.ipv4.srcAddr }, 32w1024);
                    syn_count.read(n, idx);

                    /* janela de tempo: se o ultimo inicio foi ha mais de 10 s, recomeca */
                    bit<48> t0;
                    inicio.read(t0, idx);
                    if (standard_metadata.ingress_global_timestamp - t0 > JANELA) {
                        n = 0;
                        inicio.write(idx, standard_metadata.ingress_global_timestamp);
                    }

                    n = n + 1;
                    syn_count.write(idx, n);
                    limite.read(lim, 0);
                    if (lim != 0 && n > lim) {
                        scanner = 1;    /* passou do limite da intencao */
                    }
                }

                /* 3) encaminha ou descarta */
                if (scanner == 1) {
                    drop();
                } else {
                    ipv4_lpm.apply();
                }
            }
        }
    }
}

control MyEgress(inout headers hdr,
                 inout metadata meta,
                 inout standard_metadata_t standard_metadata) {
    apply { }
}

control MyComputeChecksum(inout headers hdr, inout metadata meta) {
    apply {
        update_checksum(
            hdr.ipv4.isValid(),
            { hdr.ipv4.version,
              hdr.ipv4.ihl,
              hdr.ipv4.diffserv,
              hdr.ipv4.totalLen,
              hdr.ipv4.identification,
              hdr.ipv4.flags,
              hdr.ipv4.fragOffset,
              hdr.ipv4.ttl,
              hdr.ipv4.protocol,
              hdr.ipv4.srcAddr,
              hdr.ipv4.dstAddr },
            hdr.ipv4.hdrChecksum,
            HashAlgorithm.csum16);
    }
}

control MyDeparser(packet_out packet, in headers hdr) {
    apply {
        packet.emit(hdr.ethernet);
        packet.emit(hdr.ipv4);
        packet.emit(hdr.tcp);
    }
}

V1Switch(
MyParser(),
MyVerifyChecksum(),
MyIngress(),
MyEgress(),
MyComputeChecksum(),
MyDeparser()
) main;
