#!/usr/bin/env python3
# Varredura de portas CONTROLADA em Scapy - alternativa didatica ao nmap.
# Manda um SYN por porta, em ordem, e mostra a resposta de cada uma:
#     RST      -> porta fechada (o pacote CHEGOU em h2 e h2 respondeu)
#     SYN-ACK  -> porta aberta
#     (nada)   -> o switch descartou: a origem foi bloqueada pela intencao
#
# Com o detector em "20 portas", as 20 primeiras respondem e da 21a em diante
# nao volta nada - da para ver o exato momento em que a intencao age.
#
#   mininet> h1 python3 traffic/scan.py 10.0.2.2 --ports 1-30 --delay 0.2
import argparse
import random
import socket
import sys
import time

from scapy.all import IP, TCP, Ether, get_if_hwaddr, get_if_list, srp1


def get_if():
    for i in get_if_list():
        if "eth0" in i:
            return i
    print("Cannot find eth0 interface")
    sys.exit(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("ip_addr", help="alvo (ex: 10.0.2.2)")
    parser.add_argument("--ports", default="1-30", help="faixa, ex: 1-30 ou 20-100")
    parser.add_argument("--delay", type=float, default=0.2, help="segundos entre portas")
    parser.add_argument("--timeout", type=float, default=0.5, help="espera por resposta")
    args = parser.parse_args()

    lo, hi = (int(x) for x in args.ports.split("-"))
    addr = socket.gethostbyname(args.ip_addr)
    iface = get_if()
    print(f"varrendo {addr} portas {lo}-{hi} a partir de {iface}")

    sem_resposta = 0
    for port in range(lo, hi + 1):
        pkt = (Ether(src=get_if_hwaddr(iface), dst="ff:ff:ff:ff:ff:ff")
               / IP(dst=addr)
               / TCP(dport=port, sport=random.randint(49152, 65535), flags="S"))
        resp = srp1(pkt, iface=iface, timeout=args.timeout, verbose=False)
        if resp is None:
            sem_resposta += 1
            status = "sem resposta  <- bloqueado?"
        elif resp.haslayer(TCP) and (resp[TCP].flags & 0x04):        # RST
            status = "RST (fechada)"
        elif resp.haslayer(TCP) and (resp[TCP].flags & 0x12) == 0x12: # SYN-ACK
            status = "SYN-ACK (aberta)"
        else:
            status = f"resposta {resp.summary()}"
        print(f"  porta {port:>5}: {status}")
        sys.stdout.flush()
        if args.delay:
            time.sleep(args.delay)

    print(f"\n{hi - lo + 1} portas testadas, {sem_resposta} sem resposta")


if __name__ == "__main__":
    main()
