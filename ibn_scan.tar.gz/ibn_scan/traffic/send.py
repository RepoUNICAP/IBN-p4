#!/usr/bin/env python3
# Adaptado do send.py do tutorial basic_tunnel (sem o header MyTunnel).
# Gera trafego LEGITIMO: N pacotes TCP para UMA porta (padrao 1234).
# Como a porta nao muda, o detector conta no maximo 1 "porta nova" -> nunca bloqueia.
#
#   mininet> h3 python3 traffic/send.py 10.0.2.2 "ola h2" --count 5
import argparse
import random
import socket
import sys
import time

from scapy.all import IP, TCP, Ether, get_if_hwaddr, get_if_list, sendp


def get_if():
    for i in get_if_list():
        if "eth0" in i:
            return i
    print("Cannot find eth0 interface")
    sys.exit(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("ip_addr", help="IP de destino (ex: 10.0.2.2)")
    parser.add_argument("message", help="texto que vai no payload")
    parser.add_argument("--port", type=int, default=1234, help="porta destino (padrao 1234)")
    parser.add_argument("--count", type=int, default=1, help="quantos pacotes enviar")
    parser.add_argument("--interval", type=float, default=0.5, help="segundos entre pacotes")
    args = parser.parse_args()

    addr = socket.gethostbyname(args.ip_addr)
    iface = get_if()
    print(f"sending {args.count} packet(s) on {iface} to {addr}:{args.port}")

    for i in range(args.count):
        # dst MAC broadcast, igual ao tutorial: o switch decide pelo IP (ipv4_lpm),
        # nao pelo MAC. Flags padrao do Scapy = "S" (SYN), como uma abertura de conexao.
        pkt = (Ether(src=get_if_hwaddr(iface), dst="ff:ff:ff:ff:ff:ff")
               / IP(dst=addr)
               / TCP(dport=args.port, sport=random.randint(49152, 65535))
               / f"{args.message} #{i + 1}")
        sendp(pkt, iface=iface, verbose=False)
        print(f"  [{i + 1}/{args.count}] SYN -> {addr}:{args.port}")
        if i + 1 < args.count:
            time.sleep(args.interval)


if __name__ == "__main__":
    main()
