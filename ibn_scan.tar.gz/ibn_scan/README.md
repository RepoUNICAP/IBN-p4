# ibn_scan — Roteamento Baseado em Intenção com P4

Demo: o operador digita **"quero bloquear todos os IPs maliciosos"**, o switch
P4 passa a detectar e descartar varreduras de portas (nmap) no plano de dados.

Leia o **RELATORIO.md** — ele explica cada arquivo e o passo a passo completo.

## Início rápido (VM do p4lang/tutorials)

```bash
cp -r ibn_scan ~/tutorials/exercises/ && cd ~/tutorials/exercises/ibn_scan
sudo apt-get install -y nmap

# terminal 1
make run                      # compila o P4, sobe Mininet (h1,h2,h3 + s1)

# terminal 2
python3 ibn/ibn_cli.py        # prompt "intent>"
intent> quero bloquear todos os IPs maliciosos
intent> monitorar

# no mininet>
mininet> h1 nmap -n -Pn -sS --max-retries 1 -p 1-100 10.0.2.2
```

Sem switch (qualquer máquina): `python3 ibn/ibn_cli.py --dry-run "bloquear h1"`.
