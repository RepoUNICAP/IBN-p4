#!/usr/bin/env python3
"""
translator.py - Fase 2 do IBN: "Intent translation"

Recebe a intencao estruturada (dicionario vindo do intent_parser) e
devolve a LISTA DE COMANDOS de baixo nivel para o switch.

E a "traducao por template/blueprint" da Secao V.A do survey: cada tipo
de intencao tem um molde fixo. O programa P4 nao muda; mudam as tabelas
e os registradores que ele consulta.

    intencao (JSON)                      comandos simple_switch_CLI
    ------------------------------------ ------------------------------------------
    portscan_block  {threshold, window}  register_write cfg_threshold / cfg_window
                                         register_write cfg_enabled 0 1
    portscan_unblock                     register_write cfg_enabled 0 0
                                         register_reset  <estado do detector>
    host_block   {host}                  table_add acl acl_drop   <ip> =>
    host_allow   {host}                  table_add acl allow_host <ip> =>
    host_forget  {host}                  table_delete acl <handle>
"""

# nomes exatamente como aparecem no build/ibn_scan.p4.p4info.txtpb
TABLE_ACL        = "MyIngress.acl"
ACT_ACL_DROP     = "MyIngress.acl_drop"
ACT_ALLOW_HOST   = "MyIngress.allow_host"
REG_ENABLED      = "MyIngress.cfg_enabled"
REG_THRESHOLD    = "MyIngress.cfg_threshold"
REG_WINDOW       = "MyIngress.cfg_window"
DETECTOR_STATE   = ["MyIngress.blocked", "MyIngress.blocked_ip",
                    "MyIngress.syn_count", "MyIngress.last_port",
                    "MyIngress.window_start"]
COUNTER          = "MyIngress.intent_stats"
STAT_NAMES       = ["encaminhados", "descartados pelo detector",
                    "descartados por 'bloquear host'", "liberados (bypass)"]


class Command:
    """Um passo da ativacao: o que fazer + explicacao para o demo."""
    def __init__(self, kind, text, why, **kw):
        self.kind = kind      # 'cli' (linha da CLI) ou 'table_add'/'table_delete'
        self.text = text
        self.why = why
        self.kw = kw

    def __str__(self):
        return self.text


def translate(intent: dict, acl_state: dict) -> list:
    """
    intent    : dicionario vindo do parser (host ja resolvido para IP)
    acl_state : {ip: (handle, acao)} -> entradas atuais da tabela acl
    """
    t = intent["type"]
    cmds = []

    if t == "portscan_block":
        window_us = intent["window_s"] * 1_000_000   # o switch conta em microssegundos
        cmds.append(Command("cli", f"register_write {REG_THRESHOLD} 0 {intent['threshold']}",
                            f"tolerar ate {intent['threshold']} portas distintas"))
        cmds.append(Command("cli", f"register_write {REG_WINDOW} 0 {window_us}",
                            f"janela de {intent['window_s']} s = {window_us} us"))
        cmds.append(Command("cli", f"register_write {REG_ENABLED} 0 1",
                            "liga o detector no plano de dados"))

    elif t == "portscan_unblock":
        cmds.append(Command("cli", f"register_write {REG_ENABLED} 0 0",
                            "desliga o detector"))
        for reg in DETECTOR_STATE:
            cmds.append(Command("cli", f"register_reset {reg}",
                                "esquece contagens e bloqueios antigos"))

    elif t in ("host_block", "host_allow", "host_forget"):
        ip = intent["host"]
        if ip in acl_state:                       # ja existe regra para esse IP
            handle, _ = acl_state[ip]
            cmds.append(Command("table_delete", f"table_delete {TABLE_ACL} {handle}",
                                f"remove a regra anterior de {ip}", handle=handle))
        if t == "host_block":
            cmds.append(Command("table_add", f"table_add {TABLE_ACL} {ACT_ACL_DROP} {ip} =>",
                                f"todo pacote vindo de {ip} e descartado",
                                action=ACT_ACL_DROP, key=ip))
        elif t == "host_allow":
            cmds.append(Command("table_add", f"table_add {TABLE_ACL} {ACT_ALLOW_HOST} {ip} =>",
                                f"{ip} passa direto, sem detector",
                                action=ACT_ALLOW_HOST, key=ip))
        elif not cmds:
            cmds.append(Command("noop", "(nada a fazer)", f"{ip} nao tinha regra"))

    else:
        raise ValueError(f"tipo de intencao sem template: {t}")

    return cmds


def activate(sw, cmds):
    """Fase 4 (activation): executa os comandos no switch, em ordem."""
    for c in cmds:
        if c.kind == "table_add":
            c.handle = sw.table_add(TABLE_ACL, c.kw["action"], c.kw["key"])
        elif c.kind == "table_delete":
            sw.table_delete(TABLE_ACL, c.kw["handle"])
        elif c.kind == "cli":
            sw.run(c.text)
        # 'noop': nada
