#!/usr/bin/env python3
"""
ibn_cli.py - o "controlador de intencoes": executa o ciclo fechado do IBN
(Fig. 1 do survey) para cada frase digitada.

    frase -> [1] profiling  (intent_parser)   -> JSON
          -> [2] resolution (conflitos com o que ja esta no switch)
          -> [3] translation(translator)      -> comandos
          -> [4] activation (switch_api)      -> switch BMv2
          -> [5] assurance  (le de volta registradores/contadores)

Uso (terminal da VM, com o 'make run' rodando em outro terminal):
    python3 ibn/ibn_cli.py                       # modo interativo (REPL)
    python3 ibn/ibn_cli.py "bloquear h1"         # uma intencao e sai
    python3 ibn/ibn_cli.py --dry-run "status"    # sem switch, so mostra a traducao
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from intent_parser import parse_intent, IntentError, EXAMPLES          # noqa: E402
from translator import (translate, activate, COUNTER, STAT_NAMES,      # noqa: E402
                        REG_ENABLED, REG_THRESHOLD, REG_WINDOW)
from switch_api import Switch, SwitchError, int_to_ip                  # noqa: E402

REG_BLOCKED_IP = "MyIngress.blocked_ip"


def load_hosts(topo_path):
    """topology.json -> ({'h1': '10.0.1.1', ...}, {'10.0.1.1': 'h1', ...})"""
    with open(topo_path) as f:
        topo = json.load(f)
    name2ip = {name: h["ip"].split("/")[0] for name, h in topo["hosts"].items()}
    return name2ip, {ip: name for name, ip in name2ip.items()}


def stage(n, title, msg=""):
    print(f"[{n}/5] {title:<19}{msg}")


class IBNController:
    def __init__(self, sw, name2ip, ip2name, assume_yes=False):
        self.sw, self.name2ip, self.ip2name, self.yes = sw, name2ip, ip2name, assume_yes

    def label(self, ip):
        return f"{ip} ({self.ip2name[ip]})" if ip in self.ip2name else ip

    # ---------------- ciclo completo para UMA frase ----------------
    def handle(self, text):
        # [1] profiling
        try:
            intent = parse_intent(text)
        except IntentError as e:
            stage(1, "Intent profiling", f"nao entendi: {e}")
            return
        if "host" in intent and intent["host"] in self.name2ip:     # h1 -> 10.0.1.1
            intent["host"] = self.name2ip[intent["host"]]
        stage(1, "Intent profiling", json.dumps({k: v for k, v in intent.items() if k != "raw"},
                                                  ensure_ascii=False))

        if intent["type"] == "status":
            return self.status()
        if intent["type"] == "watch":
            return self.watch()

        # [2] resolution
        acl_state = self.sw.acl_entries()
        if not self.resolve(intent, acl_state):
            print("      intencao descartada.")
            return

        # [3] translation
        cmds = translate(intent, acl_state)
        stage(3, "Intent translation", f"{len(cmds)} comando(s) para s1 (thrift :{self.sw.thrift_port})")
        for c in cmds:
            print(f"      {c!s:<58} # {c.why}")

        # [4] activation
        try:
            activate(self.sw, cmds)
        except SwitchError as e:
            stage(4, "Intent activation", f"FALHOU: {e}")
            return
        stage(4, "Intent activation", "OK" + (" (dry-run, nada enviado)" if self.sw.dry_run else ""))

        # [5] assurance: confere se o switch ficou como a intencao pediu
        self.assure(intent)

    # ---------------- [2] resolucao de conflitos ----------------
    def resolve(self, intent, acl_state):
        t = intent["type"]
        msgs, conflict = [], False
        if t in ("host_block", "host_allow"):
            ip = intent["host"]
            if ip in acl_state:
                cur = acl_state[ip][1]
                wanted = "acl_drop" if t == "host_block" else "allow_host"
                if cur != wanted:
                    conflict = True
                    msgs.append(f"CONFLITO: ja existe intencao '{cur}' para {self.label(ip)}; "
                                f"a nova ('{wanted}') vai substituir")
                else:
                    msgs.append(f"{self.label(ip)} ja tem '{cur}'; regra sera reescrita")
            if t == "host_allow" and ip in self.detector_blocked():
                msgs.append(f"{self.label(ip)} foi bloqueado pelo DETECTOR; 'liberar' tem "
                            f"prioridade (bypass) - o detector deixa de ve-lo")
        elif t == "portscan_block":
            if self.sw.register_read(REG_ENABLED, 0) == 1:
                old = self.sw.register_read(REG_THRESHOLD, 0)
                msgs.append(f"detector ja estava ativo (limite {old}); parametros serao atualizados")
        elif t == "portscan_unblock":
            if self.sw.register_read(REG_ENABLED, 0) == 0 and not self.sw.dry_run:
                msgs.append("detector ja estava desligado")
        elif t == "host_forget" and intent["host"] not in acl_state:
            msgs.append(f"{self.label(intent['host'])} nao tinha regra")

        stage(2, "Intent resolution", "sem conflitos" if not msgs else msgs[0])
        for m in msgs[1:]:
            print(f"      {m}")
        if conflict and not self.yes:
            ans = input("      substituir a intencao anterior? [s/N] ").strip().lower()
            return ans in ("s", "sim", "y", "yes")
        return True

    # ---------------- [5] assurance ----------------
    def detector_blocked(self):
        """IPs que o detector marcou (registrador blocked_ip, valores != 0)."""
        return sorted({int_to_ip(v) for v in self.sw.register_read_all(REG_BLOCKED_IP) if v})

    def assure(self, intent):
        if self.sw.dry_run:
            return stage(5, "Intent assurance", "(dry-run) nada para conferir")
        t = intent["type"]
        if t in ("portscan_block", "portscan_unblock"):
            en = self.sw.register_read(REG_ENABLED, 0)
            th = self.sw.register_read(REG_THRESHOLD, 0)
            win = self.sw.register_read(REG_WINDOW, 0) / 1e6
            ok = (en == 1) == (t == "portscan_block")
            stage(5, "Intent assurance",
                  f"cfg_enabled={en} threshold={th} window={win:g}s  {'OK' if ok else 'DIVERGENTE'}")
        else:
            acl = self.sw.acl_entries()
            ip = intent["host"]
            got = acl.get(ip, (None, "nenhuma"))[1]
            stage(5, "Intent assurance", f"regra de {self.label(ip)} no switch: {got}")

    def status(self):
        en = self.sw.register_read(REG_ENABLED, 0)
        th = self.sw.register_read(REG_THRESHOLD, 0)
        win = self.sw.register_read(REG_WINDOW, 0) / 1e6
        print("\n  == estado das intencoes no switch s1 ==")
        print(f"  detector de varredura : {'ATIVO' if en else 'desligado'}"
              + (f"  (> {th} portas em {win:g} s)" if en else ""))
        blocked = self.detector_blocked()
        print(f"  bloqueados pelo detector: {', '.join(self.label(ip) for ip in blocked) or '-'}")
        acl = self.sw.acl_entries()
        print("  regras por host (acl)   : "
              + (", ".join(f"{self.label(ip)} -> {a}" for ip, (h, a) in acl.items()) or "-"))
        print("  contadores              :")
        for i, name in enumerate(STAT_NAMES):
            pkts, _ = self.sw.counter_read(COUNTER, i)
            print(f"     [{i}] {name:<34} {pkts:>8} pkt")
        print()

    def watch(self, interval=1.0):
        """Loop de assurance: mostra na hora quem o detector bloquear (Ctrl+C sai)."""
        print("      monitorando o switch (Ctrl+C para sair)...")
        seen = set(self.detector_blocked())
        last = self.sw.counter_read(COUNTER, 1)[0]
        try:
            while True:
                time.sleep(interval)
                now = set(self.detector_blocked())
                for ip in sorted(now - seen):
                    print(f"      {time.strftime('%H:%M:%S')}  DETECTOR bloqueou {self.label(ip)} "
                          f"-> intencao 'bloquear varreduras' cumprida")
                seen = now
                drops = self.sw.counter_read(COUNTER, 1)[0]
                if drops != last:
                    print(f"      {time.strftime('%H:%M:%S')}  pacotes descartados pelo detector: {drops}")
                    last = drops
        except KeyboardInterrupt:
            print()


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description="controlador de intencoes (IBN) para o switch s1")
    ap.add_argument("intents", nargs="*", help="intencoes; sem argumentos abre o modo interativo")
    ap.add_argument("--thrift-port", type=int, default=9090)
    ap.add_argument("--topo", default=os.path.join(here, "..", "topology.json"))
    ap.add_argument("--dry-run", action="store_true", help="nao fala com o switch")
    ap.add_argument("-y", "--yes", action="store_true", help="resolve conflitos sem perguntar")
    args = ap.parse_args()

    name2ip, ip2name = load_hosts(args.topo)
    try:
        sw = Switch(args.thrift_port, dry_run=args.dry_run)
    except SwitchError as e:
        sys.exit(f"erro: {e}")
    ctl = IBNController(sw, name2ip, ip2name, assume_yes=args.yes)

    if args.intents:
        for text in args.intents:
            print(f"\nintent> {text}")
            ctl.handle(text)
        return

    print("Controlador de intencoes - digite uma intencao (ou 'ajuda', 'sair')")
    while True:
        try:
            text = input("\nintent> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not text:
            continue
        if text.lower() in ("sair", "exit", "quit"):
            break
        if text.lower() in ("ajuda", "help", "?"):
            print("exemplos:\n  - " + "\n  - ".join(EXAMPLES))
            continue
        try:
            ctl.handle(text)
        except SwitchError as e:
            print(f"      erro no switch: {e}")


if __name__ == "__main__":
    main()
