#!/usr/bin/env python3
"""
switch_api.py - a "porta de entrada" para o switch BMv2.

Tudo aqui vira, no fim, uma linha digitada no simple_switch_CLI
(a mesma ferramenta que voces podem usar na mao para conferir):

    echo "table_dump MyIngress.acl" | simple_switch_CLI --thrift-port 9090

Por que Thrift/CLI e nao P4Runtime? O P4Runtime (usado pelo make run para
carregar o s1-runtime.json) e a API "oficial", mas no BMv2 a leitura e
escrita de REGISTRADORES - que e como parametrizamos o detector - e mais
simples e confiavel pela CLI Thrift. Os dois convivem no mesmo switch.
"""
import re
import shutil
import subprocess


class SwitchError(Exception):
    pass


def ip_to_int(ip: str) -> int:
    a, b, c, d = (int(x) for x in ip.split("."))
    return (a << 24) | (b << 16) | (c << 8) | d


def int_to_ip(n: int) -> str:
    return f"{(n >> 24) & 255}.{(n >> 16) & 255}.{(n >> 8) & 255}.{n & 255}"


class Switch:
    def __init__(self, thrift_port=9090, cli="simple_switch_CLI", dry_run=False):
        self.thrift_port = thrift_port
        self.cli = cli
        self.dry_run = dry_run
        self.log = []          # todos os comandos enviados (para mostrar no demo)
        if not dry_run and shutil.which(cli) is None:
            raise SwitchError(f"'{cli}' nao encontrado no PATH. "
                              "Rode dentro da VM do p4lang ou use --dry-run.")

    # ------------------------------------------------------------------
    # nivel mais baixo: manda UMA linha para a CLI e devolve a saida
    # ------------------------------------------------------------------
    def run(self, cmd: str) -> str:
        self.log.append(cmd)
        if self.dry_run:
            return ""
        proc = subprocess.run(
            [self.cli, "--thrift-port", str(self.thrift_port)],
            input=cmd + "\n", capture_output=True, text=True, timeout=30)
        out = proc.stdout.replace("RuntimeCmd: ", "").strip()
        err = proc.stderr.strip()
        if "Could not connect" in out + err:
            raise SwitchError(f"nao consegui falar com o switch na porta thrift "
                              f"{self.thrift_port}. O 'make run' esta rodando?")
        if re.search(r"^(Error|Invalid)", out, re.MULTILINE):
            raise SwitchError(f"o switch rejeitou '{cmd}':\n{out}")
        return out

    # ------------------------------------------------------------------
    # tabelas
    # ------------------------------------------------------------------
    def table_add(self, table, action, key, params=()):
        """table_add <tabela> <acao> <chave> => <params>  ->  handle da entrada"""
        out = self.run(f"table_add {table} {action} {key} => {' '.join(map(str, params))}")
        if self.dry_run:
            return -1
        m = re.search(r"handle (\d+)", out)
        if not m:
            raise SwitchError(f"table_add nao devolveu handle:\n{out}")
        return int(m.group(1))

    def table_delete(self, table, handle):
        self.run(f"table_delete {table} {handle}")

    def table_dump(self, table):
        """Lista [(handle, chave_hex, acao)] das entradas de uma tabela."""
        out = self.run(f"table_dump {table}")
        entries, handle, key = [], None, None
        for line in out.splitlines():
            if (m := re.match(r"Dumping entry 0x([0-9a-fA-F]+)", line)):
                handle, key = int(m.group(1), 16), None
            elif handle is not None and (m := re.search(r"EXACT\s+([0-9a-fA-F]+)", line)):
                key = m.group(1)
            elif handle is not None and (m := re.search(r"Action entry:\s*(\S+)", line)):
                entries.append((handle, key, m.group(1)))
                handle = None
        return entries

    def acl_entries(self, table="MyIngress.acl"):
        """{ip: (handle, acao_curta)} - o 'estado das intencoes por host'."""
        result = {}
        for handle, key, action in self.table_dump(table):
            if key is None:
                continue
            ip = int_to_ip(int(key, 16))
            result[ip] = (handle, action.split(".")[-1])
        return result

    # ------------------------------------------------------------------
    # registradores e contadores
    # ------------------------------------------------------------------
    def register_write(self, name, index, value):
        self.run(f"register_write {name} {index} {value}")

    def register_reset(self, name):
        self.run(f"register_reset {name}")

    def register_read(self, name, index):
        out = self.run(f"register_read {name} {index}")
        if self.dry_run:
            return 0
        m = re.search(r"=\s*(\d+)", out)
        return int(m.group(1)) if m else 0

    def register_read_all(self, name):
        """register_read sem indice devolve o array inteiro: 'nome= 0, 0, 5, ...'"""
        out = self.run(f"register_read {name}")
        if self.dry_run:
            return []
        m = re.search(r"=\s*(.*)$", out, re.MULTILINE)
        if not m:
            return []
        return [int(v) for v in re.findall(r"\d+", m.group(1))]

    def counter_read(self, name, index):
        """-> (pacotes, bytes)"""
        out = self.run(f"counter_read {name} {index}")
        if self.dry_run:
            return (0, 0)
        m = re.search(r"packets=(\d+),\s*bytes=(\d+)", out)
        return (int(m.group(1)), int(m.group(2))) if m else (0, 0)
