#!/usr/bin/env python3
"""
intent_parser.py - Fase 1 do IBN: "Intent profiling"

Recebe uma frase em portugues e devolve a intencao em formato
estruturado (um dicionario, que imprimimos como JSON).

NAO e processamento de linguagem natural "de verdade": e um vocabulario
FECHADO (verbo + objeto + condicoes) reconhecido por expressoes regulares,
no estilo verbo-objeto-sujeito descrito no survey (Secao IV.E).
A vantagem para um demo ao vivo e ser 100% previsivel.

Exemplos aceitos  ->  intencao gerada
  "bloquear todos os ips maliciosos"         -> portscan_block (limite 20 portas / 10 s)
  "bloquear quem escanear mais de 30 portas em 5 segundos"
                                             -> portscan_block (30 portas / 5 s)
  "parar de bloquear varreduras"             -> portscan_unblock
  "bloquear o ip 10.0.1.1"  /  "bloquear h1" -> host_block
  "liberar o host h1"                        -> host_allow
  "remover regra de h1"                      -> host_forget
  "status"  /  "o que esta bloqueado?"       -> status
  "monitorar"                                -> watch
"""
import re
import unicodedata

# valores usados quando a frase nao diz numeros ("ips maliciosos")
DEFAULT_THRESHOLD = 20   # portas distintas toleradas
DEFAULT_WINDOW_S  = 10   # janela de observacao, em segundos

# Definicao do que o sistema entende por "malicioso"/"suspeito".
# E a resposta ao problema de "intent definition" do survey (Secao II.B):
# o usuario fala em termos de negocio, o IBNS precisa de algo mensuravel.
MALICIOUS_DEFINITION = ("host que abre conexoes TCP (SYN) para mais de "
                        "{threshold} portas distintas em {window_s} s")

EXAMPLES = [
    "bloquear todos os ips maliciosos",
    "bloquear quem escanear mais de 30 portas em 5 segundos",
    "parar de bloquear varreduras",
    "bloquear o ip 10.0.1.1",
    "liberar o host h1",
    "remover regra de h1",
    "status",
    "monitorar",
]


class IntentError(Exception):
    """Frase fora do vocabulario. A mensagem ja vem com sugestoes."""


def normalize(text: str) -> str:
    """minusculas, sem acentos, sem pontuacao final, espacos unicos."""
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = text.lower().strip()
    text = re.sub(r"[?!.]+$", "", text)
    return re.sub(r"\s+", " ", text)


# pedacos reutilizados nas regras
HOST = r"(?P<host>\d{1,3}(?:\.\d{1,3}){3}|h\d+)"          # 10.0.1.1 ou h1
OBJ  = r"(?:o\s+|a\s+)?(?:ip\s+|host\s+|maquina\s+)?"      # "o ip ", "o host " ...
SCAN = r"(?:varredura\w*|scan\w*|port\s*scan\w*|malicios\w*|suspeit\w*|escanea\w*|detector)"


def _portscan_block(m, text):
    """'bloquear ... varreduras/maliciosos [mais de N portas] [em S segundos]'"""
    intent = {"type": "portscan_block",
              "threshold": DEFAULT_THRESHOLD,
              "window_s": DEFAULT_WINDOW_S}
    if (n := re.search(r"mais de (\d+) portas", text)):
        intent["threshold"] = int(n.group(1))
    if (s := re.search(r"em (\d+)\s*(?:s|seg|segundos)\b", text)):
        intent["window_s"] = int(s.group(1))
    intent["definition"] = MALICIOUS_DEFINITION.format(**intent)
    return intent


def _host(kind):
    return lambda m, text: {"type": kind, "host": m.group("host")}


# (regex, construtor). A ORDEM importa: a primeira que casar vence.
RULES = [
    # --- fase de assurance (consultas) ---
    (r"^(status|relatorio|mostrar|listar|o que esta bloqueado|quem esta bloqueado)\b",
     lambda m, t: {"type": "status"}),
    (r"^(monitorar|acompanhar|watch)\b",
     lambda m, t: {"type": "watch"}),

    # --- detector de varredura (antes das regras de host!) ---
    (r"\b(parar de bloquear|desativar|desligar|remover|cancelar|liberar|desbloquear)\b.*\b" + SCAN,
     lambda m, t: {"type": "portscan_unblock"}),
    (r"\b(bloquear|barrar|dropar|derrubar|impedir|detectar)\b.*\b" + SCAN,
     _portscan_block),

    # --- intencoes por host ---
    (r"\b(bloquear|barrar|dropar|derrubar)\s+" + OBJ + HOST + r"\b",
     _host("host_block")),
    (r"\b(liberar|permitir|desbloquear|confiar em)\s+" + OBJ + HOST + r"\b",
     _host("host_allow")),
    (r"\b(esquecer|remover|apagar|limpar)\s+(?:a\s+)?(?:regra\s+(?:de|do)\s+)?" + OBJ + HOST + r"\b",
     _host("host_forget")),
]


def parse_intent(text: str) -> dict:
    """Frase -> intencao estruturada. Levanta IntentError se nao entender."""
    norm = normalize(text)
    if not norm:
        raise IntentError("frase vazia. Exemplos: " + "; ".join(EXAMPLES[:3]))

    for pattern, build in RULES:
        m = re.search(pattern, norm)
        if m:
            intent = build(m, norm)
            intent["raw"] = text.strip()
            return intent

    # nao casou nada: tenta orientar o usuario (o survey chama isso de
    # "guiar o usuario ate uma intencao valida")
    if re.search(r"\b(bloquear|barrar|dropar)\b", norm):
        raise IntentError(
            "entendi 'bloquear', mas nao o que. Voce quer:\n"
            "   (a) bloquear varreduras/ips maliciosos   ex: 'bloquear todos os ips maliciosos'\n"
            "   (b) bloquear um host especifico         ex: 'bloquear o ip 10.0.1.1'")
    if re.search(r"\b(liberar|permitir)\b", norm):
        raise IntentError(
            "entendi 'liberar', mas nao o que.  ex: 'liberar o host h1' ou 'liberar varreduras'")
    raise IntentError("nao reconheci a intencao. Exemplos:\n   - " + "\n   - ".join(EXAMPLES))


if __name__ == "__main__":
    # teste rapido:  python3 intent_parser.py "bloquear o ip 10.0.1.1"
    import json
    import sys
    frases = sys.argv[1:] or EXAMPLES
    for f in frases:
        try:
            print(f"{f!r:60} -> {json.dumps(parse_intent(f), ensure_ascii=False)}")
        except IntentError as e:
            print(f"{f!r:60} -> ERRO: {e}")
