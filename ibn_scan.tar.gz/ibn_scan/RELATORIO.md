# Roteamento Baseado em Intenção com P4 — detecção e bloqueio de varredura de portas

**Seminário de Tópicos Avançados de Redes — prática de 10 minutos**
Base teórica: Leivadeas & Falkner, *A Survey on Intent-Based Networking*, IEEE COMST 2023.

---

## Sumário

1. [O que vamos demonstrar](#1-o-que-vamos-demonstrar)
2. [Arquitetura e mapeamento no IBN do survey](#2-arquitetura-e-mapeamento-no-ibn-do-survey)
3. [Estrutura do projeto](#3-estrutura-do-projeto)
4. [Preparação da VM](#4-preparação-da-vm)
5. [Topologia (`topology.json`)](#5-topologia-topologyjson)
6. [O programa P4 (`ibn_scan.p4`)](#6-o-programa-p4-ibn_scanp4)
7. [Entradas iniciais (`s1-runtime.json`)](#7-entradas-iniciais-s1-runtimejson)
8. [Fase 1 — captar a intenção: `intent_parser.py`](#8-fase-1--captar-a-intenção-intent_parserpy)
9. [Fase 2 — traduzir para o P4: `translator.py`](#9-fase-2--traduzir-para-o-p4-translatorpy)
10. [Falando com o switch: `switch_api.py`](#10-falando-com-o-switch-switch_apipy)
11. [O ciclo fechado: `ibn_cli.py`](#11-o-ciclo-fechado-ibn_clipy)
12. [Geração de tráfego: `send.py`, `receive.py`, `scan.py` e nmap](#12-geração-de-tráfego-sendpy-receivepy-scanpy-e-nmap)
13. [Execução passo a passo no Mininet](#13-execução-passo-a-passo-no-mininet)
14. [Análise com Wireshark](#14-análise-com-wireshark)
15. [Roteiro dos 10 minutos](#15-roteiro-dos-10-minutos)
16. [Problemas comuns](#16-problemas-comuns)
17. [Limitações e extensões possíveis](#17-limitações-e-extensões-possíveis)

---

## 1. O que vamos demonstrar

Um operador digita, em português, **o que ele quer** da rede — por exemplo
*"quero bloquear todos os IPs maliciosos"* — e a rede se configura sozinha:
o switch P4 passa a detectar, no próprio plano de dados, hosts que fazem
varredura de portas (port scan) e descarta o tráfego deles. O operador nunca
diz **como** fazer isso (que tabela, que registrador, que limiar). Isso é a
essência do *Intent-Based Networking* (IBN): declarar o resultado desejado, não
a configuração.

Para provocar a reação, um host da topologia roda o **nmap** (ou o nosso
`scan.py`) contra um servidor. Um terceiro host gera tráfego legítimo, que
continua passando normalmente. O Wireshark serve para mostrar, pacote a pacote,
que os SYNs da varredura chegam ao switch mas deixam de sair dele a partir do
momento em que a intenção é cumprida.

Correção importante da ideia inicial do grupo: o nmap **não detecta** varredura,
ele **é** a varredura. Na prática ele é o gerador de tráfego suspeito; quem
detecta é o programa P4.

## 2. Arquitetura e mapeamento no IBN do survey

O survey (Fig. 1, p. 627) descreve o IBNS como um ciclo fechado de cinco
componentes. Cada um tem um arquivo correspondente no projeto:

| Componente do survey | Arquivo | O que faz aqui |
|---|---|---|
| **Intent profiling** (expressar/capturar a intenção) | `ibn/intent_parser.py` | recebe a frase em português e produz um JSON estruturado |
| **Intent translation** (intenção → política de rede) | `ibn/translator.py` | JSON → lista de comandos para o switch (tradução por *template*, Seção V.A do survey) |
| **Intent resolution** (conflitos entre intenções) | `ibn/ibn_cli.py` (`resolve`) | detecta "bloquear h1" vs "liberar h1", detector já ativo etc. |
| **Intent activation** (aplicar na infraestrutura) | `ibn/switch_api.py` | escreve tabelas e registradores no BMv2 via `simple_switch_CLI` |
| **Intent assurance** (verificar que a rede cumpre) | `ibn/ibn_cli.py` (`assure`, `status`, `watch`) | lê de volta registradores e contadores do switch |
| Infraestrutura física/virtual | `ibn_scan.p4` + Mininet | o switch programável que executa a política |

```
   operador
      |  "quero bloquear todos os IPs maliciosos"
      v
 +-------------------------------- controlador (ibn_cli.py) --------------------------------+
 | [1] intent_parser  -> {"type":"portscan_block","threshold":20,"window_s":10}              |
 | [2] resolve        -> conflitos?                                                          |
 | [3] translator     -> register_write cfg_threshold 0 20 / cfg_window 0 10000000 / cfg_enabled 0 1 |
 | [4] switch_api     -> simple_switch_CLI --thrift-port 9090                                |
 | [5] assure/watch   <- register_read blocked_ip / counter_read intent_stats                |
 +-------------------------------------------|-----------------------------------------------+
                                             v  Thrift (porta 9090)
                       +---------------- s1 : BMv2 rodando ibn_scan.p4 ----------------+
   h1 (atacante) --p1--|  acl  ->  detector (registradores)  ->  ipv4_lpm             |--p2-- h2 (servidor)
   10.0.1.1            |                                                              |       10.0.2.2
   h3 (cliente)  --p3--|                                                              |
   10.0.3.3            +--------------------------------------------------------------+
```

A pergunta que o professor provavelmente vai fazer — *"a intenção gera código
P4?"* — tem resposta clara: **não**. O programa P4 é compilado uma única vez e
expõe "botões" (tabelas e registradores). A intenção só muda a posição desses
botões. É exatamente o modelo de tradução por *blueprint/template* da Seção V.A
do survey (Fig. 7): cada tipo de intenção tem um molde fixo de comandos.

## 3. Estrutura do projeto

```
ibn_scan/                     <- copiar para  ~/tutorials/exercises/ibn_scan/
├── Makefile                  usa o Makefile comum dos exercícios (make run / make stop)
├── ibn_scan.p4               plano de dados (parser, acl, detector, ipv4_lpm)
├── topology.json             h1, h2, h3 ligados ao switch s1
├── s1-runtime.json           entradas iniciais da tabela ipv4_lpm (via P4Runtime)
├── intents_demo.txt          intenções na ordem do roteiro
├── ibn/
│   ├── intent_parser.py      [1] frase -> JSON
│   ├── translator.py         [3] JSON -> comandos do switch
│   ├── switch_api.py         [4] wrapper do simple_switch_CLI (+ leitura p/ assurance)
│   └── ibn_cli.py            [2][5] REPL "intent>", resolução, assurance, watch
└── traffic/
    ├── send.py               tráfego legítimo (adaptado do basic_tunnel)
    ├── receive.py            mostra o que chega em h2 (adaptado do basic_tunnel)
    └── scan.py               varredura controlada em Scapy (alternativa ao nmap)
```

## 4. Preparação da VM

Tudo roda na VM do `p4lang/tutorials` (a mesma do `basic_tunnel`), que já traz
`p4c`, `simple_switch_grpc`, Mininet, Scapy, tcpdump e, normalmente, Wireshark.

```bash
# 1. copiar a pasta para dentro dos exercícios (o Makefile depende disso)
cp -r ibn_scan ~/tutorials/exercises/
cd ~/tutorials/exercises/ibn_scan

# 2. instalar o nmap (não vem na VM) e conferir o wireshark
sudo apt-get update && sudo apt-get install -y nmap
which wireshark || sudo apt-get install -y wireshark

# 3. teste rápido do parser e do tradutor SEM o switch (funciona em qualquer máquina)
python3 ibn/intent_parser.py
python3 ibn/ibn_cli.py --dry-run "quero bloquear todos os IPs maliciosos" "bloquear h1"
```

O `--dry-run` executa as fases 1-3 e imprime os comandos que seriam enviados,
sem precisar do switch. É útil para ensaiar a apresentação fora da VM.

## 5. Topologia (`topology.json`)

Mesmo formato que o `run_exercise.py` dos tutoriais lê:

```json
"h1": {"ip": "10.0.1.1/24", "mac": "08:00:00:00:01:11",
       "commands": ["route add default gw 10.0.1.10 dev eth0",
                    "arp -i eth0 -s 10.0.1.10 08:00:00:00:01:00"]},
...
"switches": { "s1": { "runtime_json": "s1-runtime.json" } },
"links": [ ["h1", "s1-p1"], ["h2", "s1-p2"], ["h3", "s1-p3"] ]
```

* Cada host fica em uma sub-rede própria (`10.0.X.0/24`) e tem como *gateway*
  um IP "do switch" (`10.0.X.10`) com um MAC fixo no ARP estático. Assim os
  hosts nunca precisam de ARP dinâmico — o switch P4 não implementa ARP.
* `"s1-p1"` significa porta 1 do switch. Esses números são os que aparecem em
  `egress_spec` no P4 e no `port` do `s1-runtime.json`.
* Papéis: **h1** atacante (nmap/scan.py), **h2** servidor/vítima (`receive.py`),
  **h3** cliente legítimo (`send.py`, `curl`).

## 6. O programa P4 (`ibn_scan.p4`)

O programa segue a mesma estrutura do `basic_tunnel` que vocês já fizeram
(V1Switch: parser → verify checksum → ingress → egress → compute checksum →
deparser). As diferenças estão marcadas abaixo.

### 6.1 Cabeçalhos

```p4
header tcp_t {
    bit<16> srcPort;  bit<16> dstPort;
    bit<32> seqNo;    bit<32> ackNo;
    bit<4>  dataOffset; bit<3> res; bit<1> ns;
    bit<1> cwr; bit<1> ece; bit<1> urg; bit<1> ack;
    bit<1> psh; bit<1> rst; bit<1> syn; bit<1> fin;
    bit<16> window; bit<16> checksum; bit<16> urgentPtr;
}
```

No lugar do `tunnel_t` entra o `tcp_t`. As flags TCP estão como campos de 1 bit
para que o código fale `hdr.tcp.syn == 1` em vez de máscaras de bits. Só os 20
bytes fixos do TCP são extraídos; opções e payload ficam intocados e são
reanexados pelo deparser.

Os metadados são três campos que o pipeline usa para "conversar" entre os
estágios:

```p4
struct metadata {
    bit<32> idx;      // slot do IP de origem no detector
    bit<1>  bypass;   // 1 = host liberado por intenção (pula o detector)
    bit<1>  dropped;  // 1 = alguém já mandou descartar o pacote
}
```

### 6.2 Parser

```
start -> parse_ethernet -(etherType 0x800)-> parse_ipv4 -(protocol 6)-> parse_tcp -> accept
```

É a máquina de estados do `basic_tunnel` trocando o estado `parser_Tunnel`
por `parse_tcp`, agora selecionado pelo campo `protocol` do IPv4 (6 = TCP).
Pacotes ICMP/UDP param no `accept` depois do IPv4: `hdr.tcp` fica inválido e o
detector os ignora.

### 6.3 O estado que as intenções manipulam

```p4
register<bit<32>>(1) cfg_enabled;     // 1 = intenção "bloquear varreduras" ativa
register<bit<32>>(1) cfg_threshold;   // portas distintas toleradas
register<bit<48>>(1) cfg_window;      // janela de observação, em microssegundos
```

Esses três registradores de uma posição são os "botões" da intenção
*bloquear varreduras*. O tradutor escreve neles; o pipeline os lê a cada pacote.

```p4
register<bit<32>>(N_SLOTS) syn_count;     // SYNs para portas distintas na janela
register<bit<16>>(N_SLOTS) last_port;     // última porta destino vista
register<bit<48>>(N_SLOTS) window_start;  // início da janela atual
register<bit<32>>(N_SLOTS) blocked;       // 1 = origem bloqueada
register<bit<32>>(N_SLOTS) blocked_ip;    // IP bloqueado (lido pelo controlador)
```

Estado do detector: 1024 "slots", um por IP de origem. O slot é escolhido por
um hash do IP (`crc32(srcAddr) mod 1024`). Registradores são a única memória
que sobrevive de um pacote para o outro em P4 — é o que permite "lembrar"
quantas portas um host já tocou.

```p4
counter(4, CounterType.packets) intent_stats;
```

Contadores de pacotes por motivo (encaminhado / descartado pelo detector /
descartado por ACL / liberado). São lidos na fase de *assurance*.

### 6.4 Tabelas

```p4
table acl {                            // intenções POR HOST
    key = { hdr.ipv4.srcAddr: exact; }
    actions = { acl_drop; allow_host; NoAction; }
    default_action = NoAction();
}
table ipv4_lpm {                       // encaminhamento (igual ao basic)
    key = { hdr.ipv4.dstAddr: lpm; }
    actions = { ipv4_forward; drop; NoAction; }
    default_action = drop();
}
```

* `acl` começa **vazia**. "Bloquear o IP X" insere `X -> acl_drop`; "liberar o
  host X" insere `X -> allow_host` (que só liga `meta.bypass`, fazendo o pacote
  pular o detector).
* `ipv4_lpm` é preenchida no boot pelo `s1-runtime.json`.

### 6.5 O pipeline de ingresso, passo a passo

```p4
apply {
    meta.bypass = 0;  meta.dropped = 0;
    if (hdr.ipv4.isValid()) {
        acl.apply();                                   // (1)
        bit<32> enabled;  cfg_enabled.read(enabled, 0);
        if (enabled == 1 && hdr.tcp.isValid() && meta.bypass == 0 && meta.dropped == 0) {
            hash(meta.idx, HashAlgorithm.crc32, 32w0, { hdr.ipv4.srcAddr }, N_SLOTS);   // (2)
            bit<32> is_blocked;  blocked.read(is_blocked, meta.idx);
            if (is_blocked == 1) {
                detector_drop();                       // (3)
            } else if (hdr.tcp.syn == 1 && hdr.tcp.ack == 0) {
                ... lê threshold, win_us, win_start, n_ports, lastp ...
                if (now - win_start > win_us) { n_ports = 0; window_start.write(meta.idx, now); } // (4)
                if (hdr.tcp.dstPort != lastp) { n_ports = n_ports + 1; last_port.write(meta.idx, hdr.tcp.dstPort); } // (5)
                syn_count.write(meta.idx, n_ports);
                if (n_ports > threshold) {             // (6)
                    blocked.write(meta.idx, 1);
                    blocked_ip.write(meta.idx, hdr.ipv4.srcAddr);
                    detector_drop();
                }
            }
        }
        if (meta.dropped == 0) { ipv4_lpm.apply(); }   // (7)
    }
}
```

1. **ACL primeiro.** Se a origem tem regra explícita, ela vale sobre tudo:
   `acl_drop` marca `dropped = 1`; `allow_host` marca `bypass = 1`.
2. **Slot do IP.** `hash()` transforma o IP de origem em um índice de 0 a 1023.
3. **Já bloqueado?** Se este IP já foi flagrado, descarta *qualquer* pacote
   dele (não só SYN) — é o que faz o nmap "travar".
4. **Janela deslizante.** `ingress_global_timestamp` é o relógio do switch em
   microssegundos. Se a última janela deste IP começou há mais tempo que
   `cfg_window`, zera a contagem. Assim um cliente normal, que abre poucas
   conexões por minuto, nunca acumula.
5. **Porta nova?** Só contamos SYN "puro" (abertura de conexão) e só quando a
   porta destino é diferente da última vista. Um cliente que abre 50 conexões
   com a porta 80 conta **1**; um scanner que toca 50 portas conta **50**.
6. **Passou do limite?** `n_ports > threshold` (com 20, dispara no 21º SYN
   para porta nova). Marca o slot como bloqueado, guarda o IP em `blocked_ip`
   (para o controlador poder ler *quem* foi bloqueado) e descarta.
7. **Encaminhamento.** Só chega aqui quem ninguém mandou descartar.

**Exemplo numérico** (limiar 20, janela 10 s), h1 varre as portas 1..30 de h2:

| SYN nº | porta | `n_ports` | resultado |
|---|---|---|---|
| 1 | 1 | 1 | encaminha; h2 responde RST |
| 2 | 2 | 2 | encaminha |
| ... | ... | ... | ... |
| 20 | 20 | 20 | encaminha (20 > 20 é falso) |
| 21 | 21 | 21 | **21 > 20 → bloqueia h1 e descarta** |
| 22..30 | 22..30 | — | `is_blocked == 1` → descarta sem nem contar |

Por que descartar *no switch* e não avisar o controlador? Porque a reação em
plano de dados é imediata (microssegundos) e independe do controlador estar
vivo — é a "self-healing" que o survey associa ao IBN. O controlador entra na
fase de *assurance*, lendo `blocked_ip` para relatar o que aconteceu.

### 6.6 Ações

`ipv4_forward` é idêntica ao `basic` (troca MACs, decrementa TTL, escolhe a
porta) mais `intent_stats.count(0)`. As três ações de descarte fazem o mesmo
(`mark_to_drop` + `meta.dropped = 1`), mudando só o contador incrementado —
isso é o que permite dizer, na *assurance*, *por que* cada pacote foi descartado.

### 6.7 Deparser e checksum

Iguais ao tutorial, com `packet.emit(hdr.tcp)` a mais. Como `ipv4_forward`
altera o TTL, o `update_checksum` do IPv4 é obrigatório (já estava no seu
código). O checksum TCP não é tocado porque não alteramos nada do TCP.

## 7. Entradas iniciais (`s1-runtime.json`)

O `make run` carrega este arquivo via P4Runtime logo que o switch sobe. Ele só
popula a `ipv4_lpm`:

```json
{ "table": "MyIngress.ipv4_lpm",
  "match": { "hdr.ipv4.dstAddr": ["10.0.1.1", 32] },
  "action_name": "MyIngress.ipv4_forward",
  "action_params": { "dstAddr": "08:00:00:00:01:11", "port": 1 } }
```

Leitura: "pacotes para 10.0.1.1/32 saem pela porta 1 com MAC destino do h1".
A tabela `acl` e os registradores `cfg_*` ficam **zerados**: a rede sobe sem
nenhuma intenção ativa, exatamente como um switch comum.

> O nome do arquivo p4info muda entre versões do `p4c`: `.p4info.txtpb`
> (recente) ou `.p4info.txt` (antiga). Depois do primeiro `make run`, confira
> `ls build/` e ajuste a linha `"p4info"` se necessário.

## 8. Fase 1 — captar a intenção: `intent_parser.py`

### 8.1 A decisão de projeto

O survey (Seção IV) lista quatro formas de expressar intenção: GUI/template,
NLP, linguagens de intenção (Nile, NEMO) e APIs. Escolhemos uma solução híbrida
e **determinística**: frases em português livre, mas reconhecidas por um
**vocabulário fechado** de verbos, objetos e condições (o formato
verbo-objeto-sujeito que o survey descreve na Seção IV.E). Não há modelo de
linguagem: o resultado de cada frase é sempre o mesmo, o que é o que se quer em
um demo ao vivo.

### 8.2 Normalização

```python
def normalize(text):
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    text = text.lower().strip()
    text = re.sub(r"[?!.]+$", "", text)
    return re.sub(r"\s+", " ", text)
```

Tira acentos, põe em minúsculas e remove pontuação final. "O que está
bloqueado?" vira `o que esta bloqueado`. Com isso as regras não precisam prever
variações de digitação.

### 8.3 Vocabulário

```python
HOST = r"(?P<host>\d{1,3}(?:\.\d{1,3}){3}|h\d+)"          # 10.0.1.1 ou h1
OBJ  = r"(?:o\s+|a\s+)?(?:ip\s+|host\s+|maquina\s+)?"      # "o ip ", "o host "...
SCAN = r"(?:varredura\w*|scan\w*|port\s*scan\w*|malicios\w*|suspeit\w*|escanea\w*|detector)"
```

| Categoria | Palavras reconhecidas | Campo do JSON |
|---|---|---|
| ação | bloquear, barrar, dropar, derrubar / liberar, permitir, desbloquear / parar de bloquear, desativar, remover / status, monitorar | `type` |
| alvo | `10.0.1.1`, `h1` | `host` |
| classe de tráfego | varredura, scan, malicioso, suspeito, "quem escanear" | `type` = `portscan_*` |
| condição | "mais de N portas", "em N segundos" | `threshold`, `window_s` |

### 8.4 As regras (ordem importa)

```python
RULES = [
    (r"^(status|relatorio|mostrar|listar|o que esta bloqueado|...)\b", -> {"type": "status"}),
    (r"^(monitorar|acompanhar|watch)\b",                                -> {"type": "watch"}),
    (r"\b(parar de bloquear|desativar|desligar|remover|cancelar|liberar|desbloquear)\b.*\b" + SCAN,
                                                                        -> {"type": "portscan_unblock"}),
    (r"\b(bloquear|barrar|dropar|derrubar|impedir|detectar)\b.*\b" + SCAN, -> _portscan_block),
    (r"\b(bloquear|barrar|dropar|derrubar)\s+" + OBJ + HOST,            -> {"type": "host_block"}),
    (r"\b(liberar|permitir|desbloquear|confiar em)\s+" + OBJ + HOST,    -> {"type": "host_allow"}),
    (r"\b(esquecer|remover|apagar|limpar)\s+(?:a\s+)?(?:regra\s+(?:de|do)\s+)?" + OBJ + HOST,
                                                                        -> {"type": "host_forget"}),
]
```

A primeira regra que casar vence. Por isso "parar de bloquear varreduras" está
**antes** de "bloquear ... varreduras" (senão a palavra "bloquear" da frase
ligaria o detector em vez de desligar). O `\b` (fronteira de palavra) impede
que "des**bloquear** h1" seja lido como "bloquear h1".

### 8.5 O JSON produzido

```
"quero bloquear todos os IPs maliciosos"
  -> {"type": "portscan_block", "threshold": 20, "window_s": 10,
      "definition": "host que abre conexoes TCP (SYN) para mais de 20 portas distintas em 10 s"}

"bloquear quem escanear mais de 30 portas em 5 segundos"
  -> {"type": "portscan_block", "threshold": 30, "window_s": 5, ...}

"quero bloquear o IP 10.0.1.1"   -> {"type": "host_block", "host": "10.0.1.1"}
"liberar o host h1"              -> {"type": "host_allow", "host": "h1"}
"remover regra de h1"            -> {"type": "host_forget", "host": "h1"}
"o que está bloqueado?"          -> {"type": "status"}
```

Repare no campo `definition`. "IP malicioso" é uma **abstração de negócio**;
a rede não sabe o que é isso. O parser é o lugar onde o IBNS declara sua
definição operacional: *malicioso = quem abre SYN para mais de N portas em S
segundos*. Esse é o problema de *intent definition* da Seção II.B do survey
("diferentes stakeholders têm percepções diferentes do que é uma intenção") —
vale um slide.

### 8.6 Quando não entende

```
intent> quero bloquear X IP
[1/5] Intent profiling   nao entendi: entendi 'bloquear', mas nao o que. Voce quer:
   (a) bloquear varreduras/ips maliciosos   ex: 'bloquear todos os ips maliciosos'
   (b) bloquear um host especifico         ex: 'bloquear o ip 10.0.1.1'
```

O parser reconhece o verbo, percebe que falta o objeto e sugere as opções — o
survey chama isso de "o sistema deve guiar o usuário a expressar uma intenção
válida" (p. 626).

## 9. Fase 2 — traduzir para o P4: `translator.py`

### 9.1 A tabela de templates

Esta é a resposta à segunda dificuldade do grupo. Cada `type` de intenção tem
um molde fixo de comandos de baixo nível:

| Intenção (JSON) | Comandos gerados (`simple_switch_CLI`) | Efeito no P4 |
|---|---|---|
| `portscan_block {threshold: 20, window_s: 10}` | `register_write MyIngress.cfg_threshold 0 20` `register_write MyIngress.cfg_window 0 10000000` `register_write MyIngress.cfg_enabled 0 1` | o `if (enabled == 1 ...)` do pipeline passa a ser verdadeiro |
| `portscan_unblock` | `register_write MyIngress.cfg_enabled 0 0` + `register_reset` de `blocked`, `blocked_ip`, `syn_count`, `last_port`, `window_start` | detector desligado e memória limpa |
| `host_block {host: 10.0.1.1}` | (`table_delete MyIngress.acl <handle>` se já havia regra) `table_add MyIngress.acl MyIngress.acl_drop 10.0.1.1 =>` | `acl.apply()` casa e chama `acl_drop` |
| `host_allow {host: 10.0.1.1}` | idem com `MyIngress.allow_host` | `acl.apply()` liga `bypass`, detector é pulado |
| `host_forget {host}` | `table_delete MyIngress.acl <handle>` | host volta a ser tratado como os demais |

Observações:

* O `window_s` humano (segundos) é convertido para a unidade do switch
  (microssegundos, porque `ingress_global_timestamp` é em µs). Conversão de
  unidades é uma tarefa típica da camada de tradução.
* Os nomes (`MyIngress.acl`, `MyIngress.cfg_enabled`, ...) são os nomes
  completos que aparecem no `build/ibn_scan.p4.p4info.txtpb`. Se um dia o
  programa P4 mudar, é só aqui que o tradutor precisa ser ajustado — o parser
  não muda. Essa separação (intenção ≠ configuração) é o ponto central do IBN.
* Cada comando carrega uma explicação (`why`) que o REPL imprime ao lado. No
  demo, isso mostra a tradução acontecendo.

### 9.2 `Command` e `activate`

```python
class Command:  kind ('cli' | 'table_add' | 'table_delete' | 'noop'), text, why, kw

def activate(sw, cmds):
    for c in cmds:
        if   c.kind == "table_add":    c.handle = sw.table_add(TABLE_ACL, c.kw["action"], c.kw["key"])
        elif c.kind == "table_delete": sw.table_delete(TABLE_ACL, c.kw["handle"])
        elif c.kind == "cli":          sw.run(c.text)
```

`activate` é a fase 4 (*activation*): percorre a lista e envia cada comando ao
switch. Ela é separada de `translate` de propósito — o `--dry-run` executa a
tradução sem a ativação.

## 10. Falando com o switch: `switch_api.py`

### 10.1 Por que `simple_switch_CLI` (Thrift) e não P4Runtime

O `make run` já usa P4Runtime (gRPC, porta 50051) para carregar o
`s1-runtime.json`. Para as intenções usamos o **Thrift** (porta 9090) pela
`simple_switch_CLI` — a mesma CLI que vocês podem abrir na mão. Motivos:

1. precisamos **escrever e ler registradores** (`cfg_*`, `blocked_ip`) e
   contadores; na CLI isso é um comando de uma linha;
2. o que o controlador faz fica 100% visível e reproduzível: qualquer comando
   pode ser digitado manualmente em `simple_switch_CLI --thrift-port 9090`
   para conferir;
3. os dois canais convivem no mesmo `simple_switch_grpc`.

### 10.2 Como funciona

```python
proc = subprocess.run([ "simple_switch_CLI", "--thrift-port", "9090" ],
                      input=cmd + "\n", capture_output=True, text=True)
```

Cada chamada abre a CLI, envia **uma** linha pela entrada padrão, lê a saída e
fecha. Os métodos de mais alto nível apenas montam a linha e interpretam a
resposta com expressões regulares:

| Método | Comando enviado | O que interpreta na resposta |
|---|---|---|
| `table_add(t, a, key)` | `table_add t a key =>` | `Entry has been added with handle N` → devolve `N` |
| `table_delete(t, h)` | `table_delete t h` | — |
| `table_dump(t)` / `acl_entries()` | `table_dump t` | blocos `Dumping entry 0x..` / `EXACT 0a000101` / `Action entry: ...` → `{ip: (handle, ação)}` |
| `register_write(r, i, v)` | `register_write r i v` | — |
| `register_read(r, i)` | `register_read r i` | `r[i]= 20` |
| `register_read_all(r)` | `register_read r` | `r= 0, 0, 167772417, 0, ...` → lista de inteiros |
| `register_reset(r)` | `register_reset r` | — |
| `counter_read(c, i)` | `counter_read c i` | `BmCounterValue(packets=12, bytes=720)` |

O *handle* devolvido pelo `table_add` é o "número da linha" da entrada dentro
da tabela; é ele que o `table_delete` exige. Por isso o controlador sempre
consulta `acl_entries()` antes de traduzir uma intenção por host — para saber
se precisa remover uma regra anterior e qual é o handle dela.

`ip_to_int`/`int_to_ip` convertem entre `10.0.1.1` e `167772417`, porque o
registrador `blocked_ip` guarda o IP como um inteiro de 32 bits.

## 11. O ciclo fechado: `ibn_cli.py`

### 11.1 O que acontece a cada frase

```python
def handle(self, text):
    intent = parse_intent(text)                     # [1] profiling
    if intent["host"] in self.name2ip: ...          #     h1 -> 10.0.1.1 (lê do topology.json)
    acl_state = self.sw.acl_entries()               #     estado atual do switch
    if not self.resolve(intent, acl_state): return  # [2] resolution
    cmds = translate(intent, acl_state)             # [3] translation
    activate(self.sw, cmds)                         # [4] activation
    self.assure(intent)                             # [5] assurance
```

Saída real de uma execução (`--dry-run`):

```
intent> quero bloquear todos os IPs maliciosos
[1/5] Intent profiling   {"type": "portscan_block", "threshold": 20, "window_s": 10, "definition": "..."}
[2/5] Intent resolution  sem conflitos
[3/5] Intent translation 3 comando(s) para s1 (thrift :9090)
      register_write MyIngress.cfg_threshold 0 20        # tolerar ate 20 portas distintas
      register_write MyIngress.cfg_window 0 10000000     # janela de 10 s = 10000000 us
      register_write MyIngress.cfg_enabled 0 1           # liga o detector no plano de dados
[4/5] Intent activation  OK
[5/5] Intent assurance   cfg_enabled=1 threshold=20 window=10s  OK
```

### 11.2 Resolução de conflitos (`resolve`)

O survey dedica a Seção VI a isso: intenções chegam em momentos diferentes e
podem se contradizer. Nossa política é simples e explícita:

| Situação | Comportamento |
|---|---|
| "liberar h1" mas h1 tem `acl_drop` (ou vice-versa) | avisa **CONFLITO**, pergunta `substituir? [s/N]`; se sim, a nova substitui (`table_delete` + `table_add`) |
| "liberar h1" e h1 foi bloqueado **pelo detector** | informa que a liberação tem prioridade (o `bypass` faz o detector ignorar h1) |
| "bloquear varreduras" com detector já ativo | informa que os parâmetros serão atualizados |
| "remover regra de h1" sem regra | informa "não tinha regra", não faz nada |

Prioridade implícita no P4: regra explícita por host (`acl`) > detector. Isso
está codificado na ordem `acl.apply()` → detector do pipeline.

### 11.3 Assurance (`assure`, `status`, `watch`)

* `assure` roda depois de cada ativação e **lê de volta** o que escreveu
  (registradores `cfg_*` ou a entrada da `acl`), comparando com o pedido.
* `status` ("o que está bloqueado?") imprime o estado completo: detector
  ativo/inativo e parâmetros, IPs bloqueados pelo detector (lidos de
  `blocked_ip`), regras da `acl` e os quatro contadores.
* `watch` ("monitorar") fica em loop lendo `blocked_ip` a cada segundo e avisa
  no instante em que o detector bloqueia alguém:

```
intent> monitorar
      monitorando o switch (Ctrl+C para sair)...
      14:02:11  DETECTOR bloqueou 10.0.1.1 (h1) -> intencao 'bloquear varreduras' cumprida
      14:02:12  pacotes descartados pelo detector: 79
```

É a fase de *assurance* do survey (Seção VIII): a rede reporta que a intenção
foi satisfeita, e o operador vê isso em termos da intenção, não de tabelas.

## 12. Geração de tráfego: `send.py`, `receive.py`, `scan.py` e nmap

### 12.1 `receive.py` (roda em h2 — servidor)

Adaptação direta do `receive.py` do `basic_tunnel`: mesma `get_if()`, mesmo
`sniff()`. Mudanças: filtro `"tcp"` e, em vez do `pkt.show2()` gigante, uma
linha por pacote com origem, destino, portas e **flags**:

```
10.0.1.1:54021 -> 10.0.2.2:17    flags=S   len=54
10.0.1.1:60418 -> 10.0.2.2:18    flags=S   len=54
```

(`-v` mostra o `show2()` completo, como no tutorial.) Durante a varredura a
tela rola um SYN por porta; quando a intenção bloqueia h1, **para de rolar** —
é a prova visual mais simples de que os pacotes não chegam mais.

### 12.2 `send.py` (roda em h3 — cliente legítimo)

Adaptação do `send.py` do tutorial sem o cabeçalho `MyTunnel`. Envia `--count`
pacotes TCP (flag SYN, padrão do Scapy) sempre para a **mesma** porta (1234):

```
mininet> h3 python3 traffic/send.py 10.0.2.2 "ola h2" --count 5
```

Como a porta não muda, o detector conta no máximo **uma** "porta nova" para
h3 — ele nunca é bloqueado. Isso demonstra que a intenção é seletiva.

### 12.3 `scan.py` (roda em h1 — atacante, versão controlada)

Varredura SYN escrita em Scapy, **sequencial e lenta** (`--delay 0.2`), que
imprime a resposta de cada porta:

```
mininet> h1 python3 traffic/scan.py 10.0.2.2 --ports 1-30
  porta     1: RST (fechada)
  ...
  porta    20: RST (fechada)
  porta    21: sem resposta  <- bloqueado?
  porta    22: sem resposta  <- bloqueado?
  ...
30 portas testadas, 10 sem resposta
```

`RST` significa que o SYN **chegou** em h2 (a porta estava fechada e h2
respondeu). "Sem resposta" significa que o switch descartou. Com limiar 20, a
transição acontece exatamente na porta 21 — dá para apontar na tela o momento
em que a intenção age. Use `srp1` (envio+recepção em camada 2) para não
depender de ARP.

### 12.4 nmap (roda em h1 — atacante, ferramenta real)

```
mininet> h1 nmap -n -Pn -sS --max-retries 1 -p 1-100 10.0.2.2
```

| Flag | Por quê |
|---|---|
| `-sS` | SYN scan: um SYN por porta, exatamente o padrão que o detector procura |
| `-Pn` | não faz "host discovery" (ping) antes; vai direto às portas |
| `-n` | não tenta DNS (não há DNS na topologia) |
| `--max-retries 1` | não fica reenviando para as portas sem resposta; termina rápido |
| `-p 1-100` | 100 portas: 20 vão responder, 80 vão ficar "filtered" |

Resultado esperado com a intenção ativa:

```
Not shown: 20 closed tcp ports (reset), 80 filtered tcp ports (no-response)
```

e sem a intenção: `100 closed tcp ports`. A diferença entre `closed`
(respondeu RST) e `filtered` (nada voltou) é a assinatura do bloqueio. Se o
nmap reclamar de rota/interface, acrescente `--send-ip` (usa a pilha do kernel
para enviar).

Para ter uma porta aberta e tráfego "de verdade", rode um servidor em h2:
`h2 python3 -m http.server 80 &` e, em h3, `h3 curl -s -m 2 http://10.0.2.2/ | head -3`.

## 13. Execução passo a passo no Mininet

Use **dois terminais** na VM (mais os xterms dos hosts).

### Terminal 1 — compilar e subir a rede

```bash
cd ~/tutorials/exercises/ibn_scan
make run
```

O que acontece (mesmo fluxo do `basic_tunnel`):

1. `p4c-bm2-ss` compila `ibn_scan.p4` → `build/ibn_scan.json` (o "binário" do
   BMv2) e `build/ibn_scan.p4.p4info.txtpb` (nomes de tabelas/ações);
2. `run_exercise.py` lê `topology.json`, cria h1/h2/h3 e s1 no Mininet, sobe o
   `simple_switch_grpc` com `--thrift-port 9090` e gravando pcaps em `pcaps/`;
3. carrega `s1-runtime.json` via P4Runtime;
4. executa os `commands` de cada host (rota e ARP estáticos);
5. abre o prompt `mininet>`.

Teste básico: `mininet> pingall` deve dar 0% de perda (ICMP não é TCP, o
detector ignora; o encaminhamento está funcionando).

### Terminal 2 — controlador de intenções

```bash
cd ~/tutorials/exercises/ibn_scan
python3 ibn/ibn_cli.py
intent> status
```

`status` deve mostrar detector desligado, nenhuma regra, contadores zerados
(exceto os pings encaminhados).

### xterms (a partir do `mininet>`)

```
mininet> xterm h1 h2 h3
```

* **h2**: `python3 traffic/receive.py`
* **h3**: `python3 traffic/send.py 10.0.2.2 "ola" --count 3` → h2 mostra 3
  linhas `flags=S`.
* **h1**: `nmap -n -Pn -sS --max-retries 1 -p 1-100 10.0.2.2` → **sem**
  intenção: `100 closed tcp ports`; h2 mostra 100 SYNs.

### Ativando a intenção

```
intent> quero bloquear todos os IPs maliciosos
intent> monitorar
```

No xterm de h1, repita o nmap. Em 1-2 s o terminal 2 mostra
`DETECTOR bloqueou 10.0.1.1 (h1)`; o nmap termina com `20 closed, 80 filtered`;
h2 parou de receber depois do 20º SYN. Em h3, `send.py` continua chegando.

```
intent> status
  detector de varredura : ATIVO  (> 20 portas em 10 s)
  bloqueados pelo detector: 10.0.1.1 (h1)
  contadores : [1] descartados pelo detector   81 pkt
```

### Mudando de ideia

```
intent> liberar o host h1          -> h1 volta a passar (bypass); nmap volta a dar 100 closed
intent> bloquear o ip 10.0.1.1     -> CONFLITO com a liberação; confirme com 's'; h1 nem pinga mais
intent> parar de bloquear varreduras
intent> remover regra de h1
```

### Encerrando

`mininet> exit` e, se algo ficar preso, `make stop` (= `sudo mn -c`).

## 14. Análise com Wireshark

### 14.1 Capturas automáticas

O `make run` grava **tudo que entra e sai de cada porta do switch** em
`pcaps/` (opção `--pcap` do BMv2):

| Arquivo | Conteúdo |
|---|---|
| `pcaps/s1-eth1_in.pcap` | o que h1 mandou para o switch (todos os SYNs do nmap) |
| `pcaps/s1-eth2_out.pcap` | o que o switch entregou a h2 (só os SYNs que passaram) |
| `pcaps/s1-eth2_in.pcap` | respostas de h2 (RST/SYN-ACK) |
| `pcaps/s1-eth1_out.pcap` | o que chegou de volta em h1 |

Os arquivos ficam completos após o `exit` do Mininet. Abra os dois primeiros
lado a lado:

```bash
wireshark pcaps/s1-eth1_in.pcap &
wireshark pcaps/s1-eth2_out.pcap &
```

Filtro de exibição para isolar a varredura:

```
ip.src == 10.0.1.1 && tcp.flags.syn == 1 && tcp.flags.ack == 0
```

Em `s1-eth1_in` o filtro mostra 100 pacotes (a varredura inteira); em
`s1-eth2_out` mostra **20** — a diferença é exatamente o que a intenção
descartou. Em `Statistics → Conversations → TCP` a contagem aparece por porta.
Para conferir sem abrir a interface gráfica:

```bash
tshark -r pcaps/s1-eth2_out.pcap -Y "ip.src==10.0.1.1 && tcp.flags.syn==1 && tcp.flags.ack==0" | wc -l
```

### 14.2 Captura ao vivo durante o demo

As interfaces `s1-eth1..3` do switch ficam no namespace principal da VM, então
o Wireshark comum consegue capturar nelas enquanto o Mininet roda:

```bash
sudo wireshark -i s1-eth2 -k &      # o que o switch entrega a h2
```

Com o filtro acima aplicado, a lista cresce até o 20º SYN e para. Alternativa
de terminal, dentro do xterm de h2: `tcpdump -n -i eth0 'tcp[tcpflags] & tcp-syn != 0'`.

### 14.3 O que apontar em um pacote individual

Selecione um SYN do nmap em `s1-eth1_in`:

* **Ethernet**: destino `08:00:00:00:01:00` (o MAC "do gateway" do ARP
  estático) — mostra por que o ARP estático é necessário.
* **IPv4**: `src 10.0.1.1`, `dst 10.0.2.2`, `protocol 6`, TTL 64.
* **TCP**: `Flags: 0x002 (SYN)`, porta destino diferente em cada pacote —
  é este campo (`hdr.tcp.dstPort`) que o P4 compara com `last_port`.

O mesmo pacote em `s1-eth2_out` tem MACs reescritos (`ipv4_forward`) e TTL 63
— prova de que passou pelo pipeline. Um SYN de porta > 20 simplesmente não
existe no segundo arquivo.

## 15. Roteiro dos 10 minutos

| Tempo | Ação | O que dizer |
|---|---|---|
| 0:00–1:00 | Slide com a Fig. 1 do survey e o diagrama da Seção 2 | "intenção = o quê, não o como; o P4 é a infraestrutura, o controlador fecha o loop" |
| 1:00–2:00 | Terminal 1 já com `make run`; `pingall`; `status` no terminal 2 | "rede sobe sem nenhuma intenção; é um switch comum" |
| 2:00–3:00 | h1: nmap **sem** intenção → `100 closed` | "a varredura passa; nada a impede" |
| 3:00–5:00 | `intent> quero bloquear todos os IPs maliciosos` → mostrar JSON e os 3 `register_write`; `intent> monitorar` | "aqui está a tradução: a frase virou 3 escritas de registrador; o P4 não mudou" |
| 5:00–7:00 | h1: nmap de novo → `DETECTOR bloqueou h1`; nmap `20 closed / 80 filtered`; h2 parou de receber; h3 `send.py` continua | "o switch decidiu sozinho, no plano de dados; tráfego legítimo intacto" |
| 7:00–8:30 | `intent> liberar o host h1` → nmap volta; `intent> bloquear o ip 10.0.1.1` → CONFLITO → confirmar; `intent> status` | "resolução de conflito e assurance: a rede relata em termos da intenção" |
| 8:30–10:00 | Wireshark: `s1-eth1_in` (100 SYN) vs `s1-eth2_out` (20 SYN) com o filtro | "pacote a pacote: entrou, não saiu" |

Ensaie com `python3 ibn/ibn_cli.py --dry-run` fora da VM para decorar a
sequência; use `intents_demo.txt` como cola.

## 16. Problemas comuns

| Sintoma | Causa provável / solução |
|---|---|
| `make run` falha na compilação | leia a primeira linha de erro do `p4c`; o programa foi escrito para `p4c-bm2-ss` + `v1model` da VM dos tutoriais. Se a versão da VM for muito antiga e reclamar de algo específico, mande a mensagem de erro para ajustar |
| `No such file: build/ibn_scan.p4.p4info.txtpb` | versão antiga do p4c gera `.p4info.txt`; ajuste em `s1-runtime.json` |
| `nao consegui falar com o switch na porta thrift 9090` | o `make run` não está rodando, ou é outro switch; a porta Thrift do primeiro switch é sempre 9090 |
| `simple_switch_CLI nao encontrado` | rode dentro da VM (ou use `--dry-run`) |
| nmap: `100 filtered` mesmo sem intenção | h2 não está respondendo: confira `pingall`; confira o `s1-runtime.json` (p4info/JSON) |
| nmap não envia nada / erro de rota | use `--send-ip`; confira `h1 route -n` e `h1 arp -n` |
| `scan.py`: "sem resposta" desde a porta 1 | o detector já está com h1 bloqueado de uma rodada anterior; `parar de bloquear varreduras` limpa |
| detector não bloqueia | `status` mostra `ATIVO`? A varredura é TCP SYN? (`-sS`; `-sT` também gera SYN, `-sU` não) |
| h1 continua bloqueado depois de "parar de bloquear" | a memória do detector é limpa pelo `register_reset`; se a `acl` tem `acl_drop` para h1, é outra intenção: `remover regra de h1` |
| Mininet preso / "file exists" | `make stop` (= `sudo mn -c`) e rode de novo |
| `ImportError: scapy` nos xterms | `sudo pip3 install scapy` (a VM já vem com) |

Para depurar o plano de dados, o log do switch (`logs/s1.log`) mostra cada
pacote, cada tabela consultada e cada ação executada — procure por
`detector_drop`:

```bash
grep -c detector_drop logs/s1.log
```

## 17. Limitações e extensões possíveis

* **"Portas distintas" é aproximado**: comparamos só com a *última* porta. Um
  scanner que alternasse duas portas (80, 443, 80, 443...) contaria cada
  alternância; um cliente que alterna duas portas legitimamente também. Solução
  clássica em P4: *Bloom filter* por (IP, porta) — mais registradores e mais
  hashes.
* **Colisões de hash**: 1024 slots com `crc32 mod 1024`; dois IPs podem cair no
  mesmo slot. Aumentar `N_SLOTS` ou usar dois hashes reduz o problema.
* **Bloqueio permanente**: o slot bloqueado só é limpo por intenção
  ("parar de bloquear"). Uma extensão natural é um *timeout* de bloqueio
  comparando `ingress_global_timestamp`.
* **Assurance por polling**: o controlador consulta o switch a cada segundo.
  A forma "canônica" no P4Runtime é o switch enviar um *digest* ou
  *packet-in* ao controlador quando bloqueia alguém — mais código, mesmo
  conceito.
* **Mais intenções**: o esqueleto aceita novos templates facilmente. Exemplos
  que caberiam: "limitar h3 a 1 Mbps" (`meter` no P4), "priorizar tráfego para
  h2" (`standard_metadata.priority`), "bloquear varreduras só fora do horário
  comercial" (condição temporal resolvida pelo controlador).
* **Front-end em linguagem natural**: um LLM poderia reescrever frases livres
  no JSON da Seção 8.5 e o restante do pipeline não mudaria. Não colocamos no
  demo para não depender de rede/API na hora da apresentação.

---

*Arquivos gerados para o seminário. Todo o comportamento descrito para o
parser, o tradutor e o controlador foi testado fora da VM (modo `--dry-run` e
contra uma CLI simulada com o formato de saída do BMv2). O programa P4 e o
fluxo no Mininet devem ser validados na VM do p4lang — em caso de erro de
compilação, a mensagem do `p4c` indica a linha.*
